function o = ObjectiveFunction(x)
    % change this file according to your objective function 
    o=sum(x.^2);
end